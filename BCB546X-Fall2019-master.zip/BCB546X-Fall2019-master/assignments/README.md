# Assignments

This directory will hold the information and necessary files for graded assignments


## Assignment 1: Unix

* The UNIX Assignment is available through the course GitHub repository in the [`UNIX_Assignment`](https://github.com/EEOB-BioData/BCB546X-Fall2019/tree/master/assignments/UNIX_Assignment) folder (in the `assignments` folder).
* The assignment is due via submission in Canvas by 5pm on September 27th


## Assignment 2: R

TBA

## Assignment 3: Data Management Plans

TBA

## Assignment 4: Python

TBA (2019)

## Final Project

TBA
