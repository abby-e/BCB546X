#UNIX Assignment

##Data Inspection

###Attributes of `fang_et_al_genotypes`

```
here is my snippet of code used for data inspection
```

By inspecting this file I learned that:

1. point 1
2. point 2
3. point 3

or

* point 1
* point 2
* point 3

###Attributes of `snp_position.txt`

```
here is my snippet of code used for data inspection
```

By inspecting this file I learned that:

1. point 1
2. point 2
3. point 3

or

* point 1
* point 2
* point 3

##Data Processing

###Maize Data

```
here is my snippet of code used for data processing
```

Here is my brief description of what this code does


###Teosinte Data

```
here is my snippet of code used for data processing
```

Here is my brief description of what this code does